<?php get_header(); ?>
		<div class="content_homepage">
		
		<div class="sidebar_homepage_l">
			<?php if(!dynamic_sidebar('sidebar_homepage_l')): ?>

			<?php endif; ?>
		</div>
		<div class="sidebar_homepage_r">
			<?php if(!dynamic_sidebar('sidebar_homepage_r')): ?>

			<?php endif; ?>
		</div>
		</div>
		</div>
			<?php get_footer(); ?>